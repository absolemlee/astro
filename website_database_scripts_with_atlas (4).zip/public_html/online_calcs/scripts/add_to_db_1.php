<?php
  include ('../accesscontrol.php');

  if ($is_logged_in == False)
  {
    echo "You are not yet logged in.";
    exit();
  }

  include ('../header.html');

  echo "</center>";

  // connect to the database and point to the proper database
  require_once ('../../../mysqli_connect_online_calcs_db_MYSQLI.php');
  require_once ('../../../my_functions_MYSQLI.php');

  $server_name = strtolower($_SERVER['SERVER_NAME']);

  if ($server_name == "localhost" Or $server_name == "zzee.php.gui") { $_GET['ss'] = 4; }

  //check if the form has been submitted
  if (isset($_GET['ss']))
  {
    $name1 = mysqli_real_escape_string_mimic($_GET["n"]);
    $sex1 = mysqli_real_escape_string_mimic($_GET["sex"]);

    $month1 = intval($_GET["m"]);
    $day1 = intval($_GET["d"]);
    $year1 = intval($_GET["y"]);

    $hour1 = intval($_GET["h"]);
    $minute1 = intval($_GET["min"]);

    $timezone1 = mysqli_real_escape_string_mimic($_GET["tz"]);

    //$ubt1 = intval($_GET["ubt"]);

    $long_deg1 = intval($_GET["long_deg"]);
    $long_min1 = intval($_GET["long_min"]);
    $ew1 = mysqli_real_escape_string_mimic($_GET["ew"]);

    $lat_deg1 = intval($_GET["lat_deg"]);
    $lat_min1 = intval($_GET["lat_min"]);
    $ns1 = mysqli_real_escape_string_mimic($_GET["ns"]);

    if ($ew1 == "E" Or $ew1 == "e")
    {
      $ew1 = 1;
    }
    else
    {
      $ew1 = -1;
    }

    if ($ns1 == "S" Or $ns1 == "s")
    {
      $ns1 = -1;
    }
    else
    {
      $ns1 = 1;
    }

    //=============================================================================================

    if ($server_name == "localhost" Or $server_name == "zzee.php.gui")
    {
      $name1 = "Test11";

      $sex1 = "m";

      $month1 = 9;
      $day1 = 22;
      $year1 = 1949;

      $hour1 = 10;
      $minute1 = 43;

      $timezone1 = -6;

      //$ubt1 = 0;

      $long_deg1 = 95;
      $long_min1 = 23;
      $ew1 = -1;

      $lat_deg1 = 29;
      $lat_min1 = 45;
      $ns1 = 1;
    }

    //=============================================================================================

    $date_now = date ("Y-m-d");               //get today's date

    $username = $_SESSION['username'];
    $email = $_SESSION['email'];

    //check to see if this data is already in the database
    $sql = "SELECT name, sex, entered_by FROM birth_info WHERE name='$name1' And sex='$sex1' And entered_by='$username'";
    $result = @mysqli_query($conn, $sql) or error_log(mysqli_error($conn), 0);
    $num_records = MYSQLI_NUM_rows($result);

    if ($num_records != 0)
    {
      echo "<center>";
      echo "<br><b>You have already entered this person into the database<br><br>";
      echo "<a href='view_records.php'>Click here</a> to view your database entries</a><br><br>";
      echo "</center>";

      include ('./footer.html');
      exit();
    }

    //now it is safe to enter this data into the database
    $sql = "INSERT INTO birth_info (ID,entered_by,name,sex,month,day,year,hour,minute,timezone,long_deg,long_min,ew,lat_deg,lat_min,ns,entry_date) VALUES ('','$username','$name1','$sex1','$month1','$day1','$year1','$hour1','$minute1','$timezone1','$long_deg1','$long_min1','$ew1','$lat_deg1','$lat_min1','$ns1','$date_now')";
    $result = @mysqli_query($conn, $sql) or error_log(mysqli_error($conn), 0);

    if (mysqli_affected_rows($conn) != 1)
    {
      echo "<table align='center' width='98%' border='0' cellspacing='15' cellpadding='0'><tr><td><center>";
      echo "<font color='#ff0000'><h2>There is some sort of system problem with your registration.<br><br>
           Please contact the admin of this website.</h2><h3>";
      echo "</h3></font></center></td></tr></table>";
    }
    else
    {
      $person1_id = mysqli_insert_id($conn);

      $emailTo =    "arf33@astrowin.org";

      $emailFrom =  $email;
      $emailSubject = "astrowin.org Birth Data Entry";
      $emailText =  "This is the e-mail submitted:\n\n";

      //here is the data to be submitted
      $emailText .= "id2               = " . stripslashes($new_num_records) . "\n";
      $emailText .= "Username          = " . stripslashes($username) . "\n";
      $emailText .= "Name              = " . stripslashes($name1) . "\n";
      $emailText .= "Sex               = " . stripslashes($sex1) . "\n\n";

      $emailText .= "Month             = " . stripslashes($month1) . "\n";
      $emailText .= "Day               = " . stripslashes($day1) . "\n";
      $emailText .= "Year              = " . stripslashes($year1) . "\n\n";

      $emailText .= "Hour              = " . stripslashes($hour1) . "\n";
      $emailText .= "Minute            = " . stripslashes($minute1) . "\n";
      $emailText .= "Time zone         = " . stripslashes($timezone1) . "\n\n";

      $emailText .= "Longitude deg     = " . stripslashes($long_deg1) . "\n";
      $emailText .= "Longitude min     = " . stripslashes($long_min1) . "\n";
      $emailText .= "E or W            = " . stripslashes($ew1) . "\n\n";

      $emailText .= "Latitude deg      = " . stripslashes($lat_deg1) . "\n";
      $emailText .= "Latitude min      = " . stripslashes($lat_min1) . "\n";
      $emailText .= "N or S            = " . stripslashes($ns1) . "\n\n";

      $emailText .= "Sign up date = $date_now \n\n";

      //send e-mail to user
      //@mail($emailTo, $emailSubject, $emailText, "From: $email");

      //update member_info table in database for this record
      $sql = "UPDATE member_info SET last_transaction='$date_now' WHERE username='$username'";
      $result_1 = @mysqli_query($conn, $sql) or error_log(mysqli_error($conn), 0);

      echo "<meta HTTP-EQUIV='REFRESH' content='0; url=../thanksdata.php'>";

      exit();
    }
  }


Function send_to_debug_file_192($t)
{
  $fh = fopen("debug_192.txt", "a+");

  fwrite($fh, $t . "\n");

  fclose($fh);
}

?>
