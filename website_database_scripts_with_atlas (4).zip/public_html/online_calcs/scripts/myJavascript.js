function lookup(inputString)
{
  $('#my_data_list').hide();

  if(inputString.length == 0)
  {
    $('#suggestions').hide();
  }
  else
  {
    $.post("auto_complete.php", {queryString: ""+inputString+""}, function(data)
    {
      if(data.length > 0)
      {
        $('#suggestions').show();
        $('#autoSuggestionsList').html(data);
      }
    });
  }
}

function fill_1(thisValue)
{
  $('#inputString').val(thisValue);
  setTimeout("$('#suggestions').hide();", 200);

  var city_county_and_index = document.astro_input_form.city.value;    //get city name which includes the county name separated by a ':'

  var temp = new Array();
  temp = city_county_and_index.split(':');                             //split the city name from the county name

  if (temp[1] == "undefined")
  {
    temp[1] = "";    //dont let the county be called 'undefined'
    temp[2] = "";
    temp[3] = "";
    temp[4] = "";
    temp[5] = "";
    temp[6] = "";
  }

  document.astro_input_form.city.value = temp[0];             //insert the city name into the city textbox
  document.astro_input_form.county.value = temp[1];           //insert the county name into the county textbox
  document.astro_input_form.cntry.value = temp[2] + "." + temp[5];  //insert the country name into the country textbox
  document.astro_input_form.the_lng.value = temp[3];          //insert the longitude into the longitude textbox
  document.astro_input_form.the_lat.value = temp[4];          //insert the latitude into the latitude textbox
  document.astro_input_form.county_index.value = temp[6];     //insert the county index into the county index textbox

  var $okay = "okay_to_process";
  var $city = temp[0];
  var $county = temp[1];
  var $cntry = temp[2];
  var $longitude = temp[3];
  var $latitude = temp[4];
  var $the_state = temp[5];
  var $county_index = temp[6];

  $.getJSON("display_city_data.php?okay=" + $okay + "&longitude=" + $longitude + "&latitude=" + $latitude, function(data)
  {
    if (data.found)
    {
      if (data.error_found)
      {
        $('#my_data_list').show();
        $('#my_data_list').html(data.message);
      }
      else
      {
        $("#long_deg").val(data.long_deg);
        $("#long_min").val(data.long_min);
        $("#ew").val(data.long_dir);
        $("#lat_deg").val(data.lat_deg);
        $("#lat_min").val(data.lat_min);
        $("#ns").val(data.lat_dir);
        
        document.getElementById('name').focus();
      }
    }
  });
}

