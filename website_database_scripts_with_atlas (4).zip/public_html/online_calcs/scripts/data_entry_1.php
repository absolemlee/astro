<?php
  include ('../accesscontrol.php');

  if ($is_logged_in == False)
  {
    echo "You are not yet logged in.";
    exit();
  }

  include ('../constants.php');           //nedded because of "../footer.html" statements
?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-16" />
<title>Data Entry Form - New Record</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="w3_v4.css" type='text/css' />
<link rel="stylesheet" href="myStyle.css" type='text/css' />

<!-- <link href='styles.css' rel='stylesheet' type='text/css' /> -->

<script type="text/javascript" src="jquery-1.2.1.pack.js"></script>
<script type="text/javascript" src="myJavascript.js"></script>

<style type="text/css">
.my_h3 {
  background-color: #EEEEEE;
  font-size: 11px;
  font-weight: normal;
  padding: 16px;
  margin: 0px 150px;
}
</style>
</head>

<!-- Background white, links blue (unvisited), navy (visited), red (active) -->
<body bgcolor="#c0d0ff" text="#000000" link="#0000ff" vlink="#000080" alink="#ff0000">

<link href='styles.css' rel='stylesheet' type='text/css' />
<div id='header'><img border='0' src='../images/dummy_logo.jpg' alt='Astrology scripts'></div>

<br>

<!--
<div id='content'>
<h1>Your Personal Database</h1>
<p><strong>Note: All fields are required</strong></p>
</div>

<br>
 -->

<form class="w3-container" name="astro_input_form" action="process_data.php" method="POST" target='_blank' style='margin: 0px 0px;'>
 <fieldset><legend><font size='4'><b>Find your city of birth, then enter your birth data</b></font></legend>
  <?php
    include('location_input_data.php');
    include('birth_input_data.php');
  ?>

  <input type="hidden" name="submit11" value="True">

  <input type="submit" value="Process the above data" align="left" style="background-color:#c0ffc0;font-size:16px;padding:5px 10px 5px 10px;border-radius:9px;">
 </fieldset>
</form>

<?php
  include ('./footer.html');
?>

</body>
</html>

