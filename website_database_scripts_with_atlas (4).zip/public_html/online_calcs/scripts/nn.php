<?php
  $wheel_width = 640;
  $wheel_height = $wheel_width + 50;    //includes space at top of wheel for header

  echo "<center>";
  echo "<img border='0' src='nw.php?rx1=$rx1&p1=$ser_L1&hc1=$ser_hc1&hpos=$ser_hpos&l1=$line1&ubt1=$ubt1'>";
  echo "<br><br>";

  include ('footer.html');
  exit();
?>
