<?php
  require_once ('../../../mysqli_connect_online_calcs_db_MYSQLI.php');

  $d = array();
  $num_recs = 0;

  //is there a posted query string?
  if (isset($_POST['queryString']))
  {
    $queryString = trim(safeEscapeString($_POST["queryString"])) . "%";

    if (strlen($queryString) > 2)                   //is the querystring length greater than 2?
    {
      //this is required for web server version - PhpED does not need it.
      mysqli_set_charset($conn, "latin1");          //"latin1" or "utf8" (or maybe utf-16?) - the above is no longer recommended

      $sql_1 = "SELECT * FROM geoname_cities1000 WHERE ascii_name LIKE '$queryString'";

      $result_1 = @mysqli_query($conn, $sql_1) or error_log(mysqli_error($conn), 0);

      if ($result_1)
      {
        $already_used = array();
        $list_of_cities = array();

        $num_cities = 0;

        while ($row_1 = mysqli_fetch_array($result_1, MYSQLI_ASSOC))
        {
          //get county/province info - must convert $row_1['admin1'] to its proper name
          if ($row_1['country_code'] == "US")
          {
            $admin2_code = "US." . $row_1['admin1'] . "." . $row_1['admin2'];                  //example = "US.NY.009"

            $sql = "SELECT * FROM `geoname_admin2` WHERE admin2_code='$admin2_code'";    //example = "US.NY"
            $result = @mysqli_query($conn, $sql) or error_log(mysqli_error($conn), 0);

            $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

            $d[11][$num_recs] = $row['ascii_name'];
          }
          else
          {
            $admin1_code = $row_1['country_code'] . "." . $row_1['admin1'];                //must convert $row['admin1'] to its proper name or number

            $sql = "SELECT * FROM `geoname_admin1` WHERE admin1_code='$admin1_code'";    //example = "IR.26"
            $result = @mysqli_query($conn, $sql) or error_log(mysqli_error($conn), 0);

            $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

            $d[11][$num_recs] = $row['ascii_name'];
          }

          $d[0][$num_recs] = $row_1['ascii_name'];
          $d[1][$num_recs] = $row_1['longitude'];
          $d[2][$num_recs] = $row_1['latitude'];
          $d[3][$num_recs] = $row_1['country_code'];
          $d[4][$num_recs] = $row_1['admin1'];
          $d[5][$num_recs] = $row_1['admin2'];
          $d[6][$num_recs] = $row_1['admin3'];
          $d[7][$num_recs] = $row_1['timezone'];
          $d[8][$num_recs] = $row_1['name'];
          $d[9][$num_recs] = "";
          $d[10][$num_recs] = "";

          $num_recs++;
        }
      }

//==============================================================================

      if ($num_recs >= 2)
      {
        $xyz = array_multisort($d[0], SORT_REGULAR, SORT_ASC, $d[3], SORT_REGULAR, $d[1], SORT_REGULAR, $d[2], SORT_REGULAR, $d[4], SORT_REGULAR, $d[5], SORT_REGULAR, $d[6], SORT_REGULAR, $d[7], SORT_REGULAR, $d[8], SORT_REGULAR, $d[9], SORT_REGULAR, $d[10], SORT_REGULAR, $d[11], SORT_REGULAR);
      }

      //if (isset($d) == True)
      if (empty($d) == False)
      {
        //send_to_debug_file_ac("d00 = " . $d[0][0]);

        $limit_recs = count($d[0]) - 1;
        if ($limit_recs > 35) { $limit_recs = 35; }

        for ($i = 0; $i <= $limit_recs; $i++)
        {
          $txt1 = addslashes($d[0][$i]) . ":" . addslashes($d[11][$i]) . ":" . addslashes($d[3][$i]) . ":" . $d[1][$i] . ":" . $d[2][$i] . ":" . $d[4][$i] . ":" . $d[5][$i];     //"addslashes" MUST be here
          $txt2 = $d[0][$i] . ", " . $d[11][$i] . ", " . $d[3][$i] . ":" . $d[1][$i] . ":" . $d[2][$i] . ":" . $d[4][$i] . ":" . $d[5][$i];       //no need for "addslashes" command on 1st 3 entries

          echo '<li onClick="fill_1(\'' . $txt1 . '\');">' . $txt2 . '</li>';
        }
      }
    }
  }
  else
  {
    echo 'There is no direct access to this script';
  }


Function safeEscapeString($inp)
{
  if(is_array($inp))
    return array_map(__METHOD__, $inp);

  $temp1 = str_replace("<", "[", $inp);
  $temp2 = str_replace(">", "]", $temp1);

  $temp1 = str_replace("[br]", "<br />", $temp2);
  $temp2 = str_replace("[br /]", "<br />", $temp1);

  if(!empty($temp2) && is_string($temp2))
  {
    return str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $temp2);
  }

  return $temp2;
}


Function send_to_debug_file_ac($t)
{
  $fh = fopen("debug_ac.txt", "a+");

  fwrite($fh, $t . "\n");

  fclose($fh);
}

?>
