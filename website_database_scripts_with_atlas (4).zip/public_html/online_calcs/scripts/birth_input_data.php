<?php
?>

  <table style='font-size:12px;'>
    <tr>
      <td>
        <label>Name:</label>
        <input class="w3-input w3-border w3-round-large w3-hover-light-gray w3-animate-input" type='text' size='26' maxlength='25' id='name' name='name' style="width:20%">
      </td>
    </tr>

    <tr>
      <td>
        <label>Sex:</label>
        <font size='1'> (m = male, f = female)</font>
        <input class="w3-input w3-border w3-round-large w3-hover-light-gray w3-animate-input" type='text' size='5' maxlength='2' id='sex' name='sex' style="width:20%">
      </td>
    </tr>

    <tr>
      <td>
        &nbsp;
      </td>
    </tr>

    <tr>
      <td>
        <label>Birth month: (1 - 12)</label>
        <input class="w3-input w3-border w3-round-large w3-hover-light-gray w3-animate-input" type='text' size='5' maxlength='2' id='month' name='month' style="width:20%">
      </td>
    </tr>

    <tr>
      <td>
        <label>Birth day: (1 - 31)</label>
        <input class="w3-input w3-border w3-round-large w3-hover-light-gray w3-animate-input" type='text' size='5' maxlength='2' id='day' name='day' style="width:20%">
      </td>
    </tr>

    <tr>
      <td>
        <label>Birth year: (1200 - 2399)</label>
        <input class="w3-input w3-border w3-round-large w3-hover-light-gray w3-animate-input" type='text' size='5' maxlength='4' id='year' name='year' style="width:20%">
      </td>
    </tr>

    <tr>
      <td>
        &nbsp;
      </td>
    </tr>

    <tr>
      <td>
        <label>Birth hour: (1 - 12) (if you don't know the birth time, then enter 12:00 [for noon] and then select 'Unknown')</label>
        <input class="w3-input w3-border w3-round-large w3-hover-light-gray w3-animate-input" type='text' size='4' maxlength='2' id='hour' name='hour' style="width:20%">
      </td>
    </tr>

    <tr>
      <td>
        <label>Birth minute: (0 - 59)</label>
        <input class="w3-input w3-border w3-round-large w3-hover-light-gray w3-animate-input" type='text' size='4' maxlength='2' id='minute' name='minute' style="width:20%">
      </td>
    </tr>

    <tr>
      <td>
        <label>AM or PM or birth time unknown: - choose one</label><br>
        <select class="w3-select w3-border w3-round-large w3-hover-light-gray" id="amorpm" name="amorpm" size="3" style="width:30%">
          <option value="AM"> AM </option>
          <option value="PM"> PM </option>
          <option value="unknown"> Unknown </option>
        </select>
      </td>
    </tr>

<!--
    <tr>
      <td>
        &nbsp;
      </td>
    </tr>

    <tr>
      <td>
        <label>Time zone:</label><br>
        <input size='10' id='timezone' name='timezone' style="width:55px; text-align:center;">
        <input size='25' id='time_type' name='time_type' style="width:162px; text-align:center;">
      </td>
    </tr>
-->

    <tr>
      <td>
        &nbsp;
      </td>
    </tr>
  </table>
